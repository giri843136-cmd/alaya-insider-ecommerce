import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useStore } from "./StoreContext";
import { generateToken, fingerprint, verifyTOTP } from "../lib/security";

const SESSION_KEY = "alaya_admin_session";
const SESSION_TTL = 8 * 60 * 60 * 1000; // 8 hours
const TOKEN_ROTATION_INTERVAL = 30 * 60 * 1000; // 30 minutes

const OTP_LENGTH = 6;
const OTP_TTL = 5 * 60 * 1000; // 5 minutes

// OTP brute-force protection
const OTP_LOCK_MAX = 5;
const OTP_LOCK_MS = 60_000; // 1 minute lockout
const OTP_LOCK_KEY = "alaya_admin_otp_lock";

interface AuthContextValue {
  isAdmin: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  // OTP flow
  otpPending: boolean;
  otpSentTo: { email: string; phone: string };
  otpExpiresAt: number;
  mfaMethod: "email_sms" | "totp";
  generateAndSendOTP: () => void;
  verifyOTP: (code: string) => Promise<boolean>;
  resendOTP: () => void;
  completeOtpAuth: () => void;
  // OTP rate limiting
  otpLockedUntil: number;
  /** Dev-only: the current OTP code, visible in UI when no SMS provider is configured */
  devOtpCode: string;
}

interface SessionData {
  token: string;
  fingerprint: string;
  createdAt: number;
  lastRotated: number;
  expiresAt: number;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function createSession(): SessionData {
  return {
    token: generateToken(32),
    fingerprint: JSON.stringify(fingerprint()),
    createdAt: Date.now(),
    lastRotated: Date.now(),
    expiresAt: Date.now() + SESSION_TTL,
  };
}

function validateSession(raw: string | null): boolean {
  if (!raw) return false;
  try {
    const session = JSON.parse(raw) as SessionData;
    // Check expiry
    if (Date.now() > session.expiresAt) {
      localStorage.removeItem(SESSION_KEY);
      return false;
    }
    // Optional: verify fingerprint hasn't changed drastically (basic session hijacking detection)
    return true;
  } catch {
    return false;
  }
}

function readSession(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    return validateSession(raw);
  } catch {
    return false;
  }
}

function updateSessionActivity() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return;
    const session = JSON.parse(raw) as SessionData;
    // Rotate token every 30 minutes
    if (Date.now() - session.lastRotated > TOKEN_ROTATION_INTERVAL) {
      session.token = generateToken(32);
      session.lastRotated = Date.now();
    }
    session.expiresAt = Date.now() + SESSION_TTL;
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch { /* ignore */ }
}

/** Mask an email for display: j***@domain.com */
function maskEmail(email: string): string {
  const [name, domain] = email.split("@");
  if (!name || !domain) return email;
  return `${name[0]}***@${domain}`;
}

/** Mask a phone number for display: +1 (***) ***-0148 */
function maskPhone(phone: string): string {
  if (!phone) return "";
  const digits = phone.replace(/\D/g, "");
  if (digits.length <= 4) return phone;
  return `${phone.slice(0, -4)}****`;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const { settings, updateSettings, log } = useStore();
  const [isAdmin, setIsAdmin] = useState<boolean>(readSession);

  // OTP state — kept in memory only, never persisted to localStorage
  const [otpPending, setOtpPending] = useState(false);
  const otpCodeRef = useRef<string>("");
  const otpExpiresAtRef = useRef<number>(0);
  const [otpExpiresAt, setOtpExpiresAt] = useState(0);
  const [devOtpCode, setDevOtpCode] = useState("");

  // OTP rate limiting — persisted to localStorage for parity with password lockout
  const [otpLockedUntil, setOtpLockedUntil] = useState(() => {
    try {
      return Number(window.localStorage.getItem(OTP_LOCK_KEY)) || 0;
    } catch {
      return 0;
    }
  });
  const otpAttemptsRef = useRef<number>(0);

  const completeOtpAuth = useCallback(() => {
    const session = createSession();
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    setIsAdmin(true);
    setOtpPending(false);
    setDevOtpCode("");
    otpCodeRef.current = "";
    // Start periodic session refresh
    const interval = setInterval(() => {
      updateSessionActivity();
    }, 60_000);
    (window as any).__alaya_session_refresh = interval;
  }, []);

  const login = useCallback(
    (email: string, password: string) => {
      const emailOk = email.toLowerCase() === (settings.adminEmail || "").toLowerCase();
      const passwordOk = password === settings.adminPassword;
      const ok = emailOk && passwordOk;
      if (ok) {
        log("auth.credentials_verified", "admin", `Admin verified — OTP required`);
      } else if (!emailOk) {
        log("auth.login_failed", "admin", `Login failed — unrecognised email`);
      }
      return ok;
    },
    [settings.adminEmail, settings.adminPassword, log]
  );

  const generateAndSendOTP = useCallback(() => {
    const code = Array.from({ length: OTP_LENGTH }, () =>
      Math.floor(Math.random() * 10).toString()
    ).join("");
    otpCodeRef.current = code;
    setDevOtpCode(code);
    const expiresAt = Date.now() + OTP_TTL;
    otpExpiresAtRef.current = expiresAt;
    setOtpExpiresAt(expiresAt);
    setOtpPending(true);

    // Use dedicated admin email/phone with fallbacks to store contact info
    const otpEmail = settings.adminEmail || settings.contactEmail;
    const otpPhone = settings.adminPhone || settings.contactPhone;

    // Send OTP via backend SMS service (MessageBird)
    const backendUrl = (() => {
      try {
        const raw = localStorage.getItem("alaya_api_config");
        if (raw) {
          const cfg = JSON.parse(raw);
          if (cfg.apiUrl) return cfg.apiUrl;
        }
      } catch { /* ignore */ }
      return "http://localhost:3001/api/v1";
    })();

    fetch(`${backendUrl}/auth/send-otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: otpEmail }),
    })
      .then((res) => {
        if (!res.ok) log("auth.otp_backend_error", "system", `Backend SMS endpoint returned ${res.status}`);
        return res.json();
      })
      .then((data) => {
        if (data.status === "dev_mode") {
          log("auth.otp_dev", "system", `Dev mode OTP: ${data.otpCode || data.devOtp || "(check server logs)"}`);
        } else if (data.success) {
          log("auth.otp_sms_sent", "system", `SMS OTP sent via backend to ${data.phone}`);
        }
      })
      .catch((err: Error) => {
        log("auth.otp_backend_unreachable", "system", `Backend SMS unavailable: ${err.message}`);
      });

    // Log OTP for audit trail
    log("auth.otp_sent", "email", `OTP sent to ${otpEmail}`);
    log("auth.otp_sent", "sms", `OTP sent to ${otpPhone}`);
  }, [settings.adminEmail, settings.adminPhone, settings.contactEmail, settings.contactPhone, log]);

  const verifyOTP = useCallback(async (code: string): Promise<boolean> => {
    // Check OTP rate limit
    if (Date.now() < otpLockedUntil) {
      log("auth.otp_rate_limited", "admin", "OTP verification blocked — rate limited");
      return false;
    }
    // Reset counter if lockout has expired, giving full fresh attempts
    if (otpAttemptsRef.current >= OTP_LOCK_MAX) {
      otpAttemptsRef.current = 0;
      setOtpLockedUntil(0);
      try { window.localStorage.removeItem(OTP_LOCK_KEY); } catch { /* ignore */ }
    }

    // TOTP mode — verify against authenticator app or backup codes
    if (settings.mfaMethod === "totp" && settings.totpSecret) {
      // Check backup codes first (one-time use, consumed after successful verification)
      const backupIdx = settings.totpBackupCodes?.indexOf(code);
      if (backupIdx !== undefined && backupIdx !== -1) {
        log("auth.backup_code_used", "admin", "TOTP verified via backup code");
        // Consume the backup code: remove it from settings so it can't be reused
        const updated = [...settings.totpBackupCodes];
        updated.splice(backupIdx, 1);
        updateSettings({ totpBackupCodes: updated });
        otpAttemptsRef.current = 0;
        return true;
      }

      const ok = await verifyTOTP(settings.totpSecret, code);
      if (ok) {
        log("auth.totp_verified", "admin", "TOTP verified via authenticator app");
        otpAttemptsRef.current = 0;
        return true;
      }
      log("auth.totp_invalid", "admin", "TOTP verification failed — invalid code");
      // Increment failed TOTP attempt counter
      otpAttemptsRef.current += 1;
      if (otpAttemptsRef.current >= OTP_LOCK_MAX) {
        const until = Date.now() + OTP_LOCK_MS;
        setOtpLockedUntil(until);
        try { window.localStorage.setItem(OTP_LOCK_KEY, String(until)); } catch { /* ignore */ }
        log("auth.otp_locked", "admin", "OTP locked — too many failed attempts");
      }
      return false;
    }

    // Email/SMS OTP mode — verify against in-memory code
    if (Date.now() > otpExpiresAtRef.current) {
      log("auth.otp_expired", "admin", "OTP verification failed — code expired");
      otpAttemptsRef.current += 1;
      if (otpAttemptsRef.current >= OTP_LOCK_MAX) {
        const until = Date.now() + OTP_LOCK_MS;
        setOtpLockedUntil(until);
        try { window.localStorage.setItem(OTP_LOCK_KEY, String(until)); } catch { /* ignore */ }
        log("auth.otp_locked", "admin", "OTP locked — too many failed attempts");
      }
      return false;
    }
    if (code !== otpCodeRef.current) {
      log("auth.otp_invalid", "admin", "OTP verification failed — invalid code");
      otpAttemptsRef.current += 1;
      if (otpAttemptsRef.current >= OTP_LOCK_MAX) {
        const until = Date.now() + OTP_LOCK_MS;
        setOtpLockedUntil(until);
        try { window.localStorage.setItem(OTP_LOCK_KEY, String(until)); } catch { /* ignore */ }
        log("auth.otp_locked", "admin", "OTP locked — too many failed attempts");
      }
      return false;
    }
    log("auth.otp_verified", "admin", "OTP verified successfully");
    otpAttemptsRef.current = 0;
    return true;
  }, [log, settings.mfaMethod, settings.totpSecret, settings.totpBackupCodes, updateSettings, otpLockedUntil]);

  const resendOTP = useCallback(() => {
    generateAndSendOTP();
  }, [generateAndSendOTP]);

  const logout = useCallback(() => {
    window.localStorage.removeItem(SESSION_KEY);
    setIsAdmin(false);
    setOtpPending(false);
    setDevOtpCode("");
    otpCodeRef.current = "";
    // Clear session refresh interval
    const interval = (window as any).__alaya_session_refresh;
    if (interval) {
      clearInterval(interval);
      delete (window as any).__alaya_session_refresh;
    }
  }, []);

  const otpSentTo = useMemo(
    () => ({
      email: maskEmail(settings.adminEmail || settings.contactEmail || "admin@alayainsider.com"),
      phone: maskPhone(settings.adminPhone || settings.contactPhone || "+1 (212) 555-0148"),
    }),
    [settings.adminEmail, settings.adminPhone, settings.contactEmail, settings.contactPhone]
  );

  const mfaMethod = useMemo(() => settings.mfaMethod || "email_sms", [settings.mfaMethod]);

  const value = useMemo<AuthContextValue>(
    () => ({
      isAdmin,
      login,
      logout,
      otpPending,
      otpSentTo,
      otpExpiresAt,
      mfaMethod,
      generateAndSendOTP,
      verifyOTP,
      resendOTP,
      completeOtpAuth,
      otpLockedUntil,
      devOtpCode,
    }),
    [
      isAdmin,
      login,
      logout,
      otpPending,
      otpSentTo,
      otpExpiresAt,
      mfaMethod,
      generateAndSendOTP,
      verifyOTP,
      resendOTP,
      completeOtpAuth,
      otpLockedUntil,
      devOtpCode,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within <AuthProvider>");
  return ctx;
}
