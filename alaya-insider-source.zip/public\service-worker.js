// ALAYA INSIDER — Service Worker v1.0.0
const CACHE = "alaya-cache-v1";
const STATIC_ASSETS = ["/", "/manifest.json", "/icons/icon-192.svg", "/icons/icon-512.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(STATIC_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  // Cache-first for static assets
  if (request.url.match(/\.(svg|png|jpg|jpeg|gif|ico|css|js|woff2?)$/)) {
    event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((res) => { const clone = res.clone(); caches.open(CACHE).then((c) => c.put(request, clone)); return res; })));
    return;
  }
  // Network-first for navigation
  event.respondWith(
    fetch(request).then((res) => {
      const clone = res.clone();
      caches.open(CACHE).then((c) => c.put(request, clone));
      return res;
    }).catch(() => caches.match(request).then((cached) => cached || new Response("Offline", { status: 503 })))
  );
});
