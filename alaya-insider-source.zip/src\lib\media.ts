/**
 * ALAYA INSIDER — Digital Asset Management (DAM) Engine
 * -----------------------------------------------------------------
 * Indexes, analyzes, and manages every media asset referenced across the
 * platform. Assets are derived from the live catalogue (product images,
 * brand logos, article covers, hero slides) so the DAM is always accurate
 * and requires no separate upload step for existing content.
 */
import type { Product, Brand, Article, Category, Settings } from "./types";

/** Minimal interface needed by the DAM indexer (avoids coupling to StoreData). */
export interface IndexableData {
  products: Product[];
  brands: Brand[];
  articles: Article[];
  categories: Category[];
  settings: Settings;
}

export type AssetType = "image" | "video" | "document";
export type AssetSource = "product" | "brand" | "article" | "hero" | "category";

export interface MediaAsset {
  id: string;
  url: string;
  type: AssetType;
  source: AssetSource;
  refId: string;     // product id, brand id, etc.
  refName: string;   // human label
  title: string;
  alt: string;
  tags: string[];
  sizeKb: number;
  width: number;
  height: number;
  optimized: boolean;
  webp: boolean;
  avif: boolean;
  usageCount: number;
  duplicateOf?: string;
  qualityScore: number;
  createdAt: number;
}

/** Derive a MIME type / category from a URL. */
function detectType(url: string): AssetType {
  const lower = url.toLowerCase();
  if (/\.(mp4|webm|mov)$/.test(lower)) return "video";
  if (/\.(pdf|docx|xlsx|zip|txt|csv)$/.test(lower)) return "document";
  return "image";
}

/** Deterministic pseudo-size + dimensions from a URL hash (for demo realism). */
function hashStr(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return Math.abs(h);
}
function deriveMeta(url: string) {
  const h = hashStr(url);
  const ext = url.split(".").pop()?.toUpperCase() || "JPG";
  const sizeKb = 40 + (h % 380);
  const ratios: [number, number][] = [[800, 1200], [1000, 1300], [1600, 900], [1200, 800], [500, 500]];
  const [width, height] = ratios[h % ratios.length];
  return { sizeKb, width, height, ext };
}

/** Generate AI-ready alt text from context. */
export function genAltText(refName: string, source: AssetSource, index = 0): string {
  const labels: Record<AssetSource, string> = {
    product: "product photography",
    brand: "brand image",
    article: "editorial cover image",
    hero: "hero banner",
    category: "category image",
  };
  const variant = index === 0 ? "" : ` view ${index + 1}`;
  return `${refName} — ${labels[source]}${variant}`;
}

/** Quality score 0–100 based on format, size, dimensions. */
export function qualityScore(asset: { type: AssetType; sizeKb: number; width: number; height: number; optimized: boolean }): number {
  let score = 50;
  if (asset.width >= 800) score += 15;
  if (asset.height >= 600) score += 10;
  if (asset.sizeKb < 250) score += 15;
  if (asset.optimized) score += 10;
  return Math.min(100, score);
}

/** Index all media from the store into a flat asset list. */
export function indexAssets(data: IndexableData): MediaAsset[] {
  const assets: MediaAsset[] = [];
  const seen = new Set<string>();

  const add = (url: string, source: AssetSource, refId: string, refName: string, index = 0) => {
    if (!url || seen.has(url)) return;
    seen.add(url);
    const meta = deriveMeta(url);
    const type = detectType(url);
    const id = `media_${hashStr(url)}`;
    assets.push({
      id, url, type, source, refId, refName,
      title: refName,
      alt: genAltText(refName, source, index),
      tags: [source, type, meta.ext.toLowerCase()],
      ...meta,
      optimized: type !== "image" ? true : meta.sizeKb < 120,
      webp: type !== "image",
      avif: false,
      usageCount: 1,
      qualityScore: 0,
      createdAt: Date.now(),
    });
  };

  data.products.forEach((p: Product) => p.images.forEach((u, i) => add(u, "product", p.id, p.name, i)));
  data.brands.forEach((b: Brand) => add(b.image, "brand", b.id, b.name));
  data.articles.forEach((a: Article) => add(a.cover, "article", a.id, a.title));
  data.categories.forEach((c) => add(c.image, "category", c.id, c.name));
  data.settings.heroSlides.forEach((s) => add(s.image, "hero", s.id, s.eyebrow));

  // detect duplicates (same refName + similar dimensions = near-dup)
  const byName: Record<string, MediaAsset[]> = {};
  assets.forEach((a) => { (byName[a.refName] ||= []).push(a); });
  assets.forEach((a) => { a.qualityScore = qualityScore(a); });

  return assets;
}

/** Find duplicate / near-duplicate assets. */
export function findDuplicates(assets: MediaAsset[]): MediaAsset[] {
  const dupes: MediaAsset[] = [];
  const byDim: Record<string, MediaAsset[]> = {};
  assets.forEach((a) => {
    const key = `${a.width}x${a.height}`;
    (byDim[key] ||= []).push(a);
  });
  Object.values(byDim).forEach((group) => {
    if (group.length > 1) {
      group.slice(1).forEach((a) => { a.duplicateOf = group[0].id; dupes.push(a); });
    }
  });
  return dupes;
}

/** Find unused assets (not referenced by any active entity). */
export function findUnused(assets: MediaAsset[], data: IndexableData): MediaAsset[] {
  const activeIds = new Set<string>([
    ...data.products.flatMap((p) => p.images),
    ...data.brands.map((b) => b.image),
    ...data.articles.map((a) => a.cover),
    ...data.categories.map((c) => c.image),
    ...data.settings.heroSlides.map((s) => s.image),
  ]);
  return assets.filter((a) => !activeIds.has(a.url));
}

/** Storage + type summary for the dashboard. */
export function mediaStats(assets: MediaAsset[]) {
  const byType = { image: 0, video: 0, document: 0 };
  let totalKb = 0;
  assets.forEach((a) => { byType[a.type]++; totalKb += a.sizeKb; });
  const optimized = assets.filter((a) => a.optimized).length;
  const potentialSavings = assets
    .filter((a) => !a.optimized)
    .reduce((s, a) => s + Math.round(a.sizeKb * 0.4), 0);
  return {
    total: assets.length,
    byType,
    totalMb: (totalKb / 1024).toFixed(1),
    optimized,
    unoptimized: assets.length - optimized,
    potentialSavingsKb: potentialSavings,
  };
}

/** Simulate optimizing an asset (compress + generate formats). */
export function optimizeAsset(asset: MediaAsset): MediaAsset {
  return {
    ...asset,
    optimized: true,
    webp: true,
    avif: true,
    sizeKb: Math.round(asset.sizeKb * 0.6),
    qualityScore: qualityScore({ ...asset, optimized: true, sizeKb: Math.round(asset.sizeKb * 0.6) }),
  };
}
