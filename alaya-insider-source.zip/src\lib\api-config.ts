/**
 * ALAYA INSIDER — API Configuration
 * --------------------------------------------------------------------------
 * Provides runtime configuration for the backend API connection.
 *
 * Configuration source priority:
 *  1. Runtime window.__ALAYA_CONFIG__ (injected via index.html at deploy time)
 *  2. Environment variables (import.meta.env.VITE_*)
 *  3. localStorage (user-configured in Settings > Developer)
 *  4. Defaults (localStorage fallback only)
 */

/* ================================================================== */
/*  TYPES                                                              */
/* ================================================================== */

export interface ApiConfig {
  /** Base URL of the backend REST API (e.g. https://api.alayainsider.com/v1). */
  apiUrl: string;

  /** Bearer token for JWT/OAuth2 authentication. */
  authToken?: string;

  /** Alternative: API key for X-API-Key authentication. */
  apiKey?: string;

  /** Request timeout in milliseconds. Default: 15_000. */
  timeoutMs: number;

  /** Maximum number of automatic retries. Default: 3. */
  maxRetries: number;

  /** Whether to send credentials (cookies) with cross-origin requests. */
  includeCredentials: boolean;

  /** Enable response caching. Default: true. */
  cacheEnabled: boolean;

  /** Debug logging to console. */
  debug: boolean;

  /** Feature flag: use localStorage fallback when API is unreachable. */
  localStorageFallback: boolean;
}

/* ================================================================== */
/*  DEFAULTS                                                           */
/* ================================================================== */

const DEFAULT_CONFIG: ApiConfig = {
  apiUrl: "",
  authToken: undefined,
  apiKey: undefined,
  timeoutMs: 15_000,
  maxRetries: 3,
  includeCredentials: false,
  cacheEnabled: true,
  debug: false,
  localStorageFallback: true,
};

const STORAGE_KEY = "alaya_api_config";

/* ================================================================== */
/*  LOADERS                                                            */
/* ================================================================== */

/**
 * Try to read runtime config injected via window.__ALAYA_CONFIG__.
 * This is set from the server side at deploy time.
 */
function loadRuntimeConfig(): Partial<ApiConfig> | null {
  try {
    const runtime =
      typeof window !== "undefined" &&
      (window as unknown as Record<string, unknown>).__ALAYA_CONFIG__;
    if (runtime && typeof runtime === "object") {
      return runtime as Partial<ApiConfig>;
    }
  } catch {
    // ignore
  }
  return null;
}

/**
 * Try to read Vite environment variables (build-time).
 */
function loadEnvConfig(): Partial<ApiConfig> {
  try {
    const env = (import.meta as { env?: Record<string, string | undefined> }).env ?? {};
    return {
      apiUrl: env.VITE_API_URL ?? env.ALAYA_API_URL ?? "",
      authToken: env.VITE_API_TOKEN ?? env.ALAYA_API_TOKEN ?? undefined,
      apiKey: env.VITE_API_KEY ?? env.ALAYA_API_KEY ?? undefined,
      timeoutMs: env.VITE_API_TIMEOUT
        ? Number(env.VITE_API_TIMEOUT)
        : DEFAULT_CONFIG.timeoutMs,
      maxRetries: env.VITE_API_MAX_RETRIES
        ? Number(env.VITE_API_MAX_RETRIES)
        : DEFAULT_CONFIG.maxRetries,
      debug: env.VITE_API_DEBUG === "true",
      localStorageFallback:
        env.VITE_LOCALSTORAGE_FALLBACK !== "false",
    };
  } catch {
    return {};
  }
}

/**
 * Load user-configured API settings from localStorage.
 */
function loadLocalStorageConfig(): Partial<ApiConfig> | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as Partial<ApiConfig>;
    }
  } catch {
    // ignore
  }
  return null;
}

/* ================================================================== */
/*  PUBLIC API                                                         */
/* ================================================================== */

/**
 * Get the effective API configuration by merging all sources.
 * Priority: runtime → env → localStorage → defaults.
 */
export function getApiConfig(): ApiConfig {
  const runtime = loadRuntimeConfig();
  const env = loadEnvConfig();
  const local = loadLocalStorageConfig();

  return {
    ...DEFAULT_CONFIG,
    ...local,
    ...env,
    ...runtime,
  };
}

/**
 * Persist API configuration to localStorage (for the Settings UI).
 * Overwrites previous saved config entirely.
 */
export function saveApiConfig(config: Partial<ApiConfig>): void {
  try {
    const existing = loadLocalStorageConfig() ?? {};
    const merged = { ...existing, ...config };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  } catch {
    // ignore quota errors
  }
}

/**
 * Clear persisted API configuration from localStorage.
 */
export function clearApiConfig(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

/**
 * Check if the API has been configured with a valid URL.
 */
export function isApiConfigured(): boolean {
  const cfg = getApiConfig();
  return Boolean(cfg.apiUrl && cfg.apiUrl.startsWith("http"));
}

/**
 * Get the display-friendly name of the current API configuration state.
 */
export function getApiStatus(): {
  configured: boolean;
  mode: "remote" | "local" | "hybrid";
  url: string;
} {
  const cfg = getApiConfig();
  const configured = Boolean(cfg.apiUrl);
  return {
    configured,
    mode: configured
      ? cfg.localStorageFallback
        ? "hybrid"
        : "remote"
      : "local",
    url: cfg.apiUrl || "localStorage (no backend)",
  };
}
