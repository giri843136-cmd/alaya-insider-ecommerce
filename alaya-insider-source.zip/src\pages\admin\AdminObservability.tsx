/**
 * ALAYA INSIDER — Enterprise Observability Admin UI
 * Tab-based dashboard for logs, tracing, health, incidents, audit, dashboards,
 * monitoring rules, alerts, metrics, topology, reports, errors, and activity.
 */
import { useState } from "react";
import {
  Activity, BarChart3, Shield, FileText, Bell, Map,
  Eye, Server, AlertTriangle, ClipboardList, Users,
  RefreshCw, CheckCircle2, XCircle, Clock, AlertCircle,
  Fingerprint, Search, Filter, Plus, Trash2, Layers, GitBranch,
} from "lucide-react";
import { Seo } from "../../components/Seo";
import { useToast } from "../../context/ToastContext";
import { useObservability } from "../../context/ObservabilityContext";
import { formatDateTime } from "../../lib/utils";
import { cn } from "@/utils/cn";
import type { OperationalReport } from "../../lib/observability";

type Tab =
  | "overview" | "logs" | "tracing" | "health"
  | "incidents" | "audit" | "dashboards"
  | "alerts" | "metrics" | "topology"
  | "reports" | "errors" | "activity";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Overview", icon: Activity },
  { id: "logs", label: "Logs", icon: FileText },
  { id: "tracing", label: "Tracing", icon: Fingerprint },
  { id: "health", label: "Health", icon: Server },
  { id: "incidents", label: "Incidents", icon: AlertTriangle },
  { id: "audit", label: "Audit", icon: Shield },
  { id: "dashboards", label: "Dashboards", icon: LayoutsIcon },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "metrics", label: "Metrics", icon: BarChart3 },
  { id: "topology", label: "Topology", icon: Map },
  { id: "reports", label: "Reports", icon: ClipboardList },
  { id: "errors", label: "Errors", icon: XCircle },
  { id: "activity", label: "Activity", icon: Users },
];

function LayoutsIcon(props: any) { return <Layers {...props} />; }

export default function AdminObservability() {
  const { toast } = useToast();
  const ctx = useObservability();
  const [tab, setTab] = useState<Tab>("overview");

  return (
    <>
      <Seo title="Observability" path="/admin/observability" />
      <div className="p-5 sm:p-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold text-ink">Observability</h1>
            <p className="mt-1 text-sm text-muted">
              Operational intelligence — logging, tracing, monitoring, alerting & audit.
            </p>
          </div>
          <button onClick={() => { ctx.refresh(); toast.success("Observability data refreshed"); }} className="btn-outline btn-sm">
            <RefreshCw className="h-4 w-4" /> Refresh
          </button>
        </div>

        {/* Tab bar */}
        <div className="mt-6 flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn("chip capitalize", tab === t.id && "chip-active")}
            >
              <t.icon className="h-3.5 w-3.5" /> {t.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        {tab === "overview" && <OverviewTab ctx={ctx} />}

        {/* LOGS */}
        {tab === "logs" && <LogsTab ctx={ctx} />}

        {/* TRACING */}
        {tab === "tracing" && <TracingTab ctx={ctx} />}

        {/* HEALTH */}
        {tab === "health" && <HealthTab ctx={ctx} />}

        {/* INCIDENTS */}
        {tab === "incidents" && <IncidentsTab ctx={ctx} />}

        {/* AUDIT */}
        {tab === "audit" && <AuditTab ctx={ctx} />}

        {/* DASHBOARDS */}
        {tab === "dashboards" && <DashboardsTab ctx={ctx} />}

        {/* ALERTS */}
        {tab === "alerts" && <AlertsTab ctx={ctx} />}

        {/* METRICS */}
        {tab === "metrics" && <MetricsTab ctx={ctx} />}

        {/* TOPOLOGY */}
        {tab === "topology" && <TopologyTab ctx={ctx} />}

        {/* REPORTS */}
        {tab === "reports" && <ReportsTab ctx={ctx} />}

        {/* ERRORS */}
        {tab === "errors" && <ErrorsTab ctx={ctx} />}

        {/* ACTIVITY */}
        {tab === "activity" && <ActivityTab ctx={ctx} />}
      </div>
    </>
  );
}

/* ================================================================== */
/*  OVERVIEW TAB                                                       */
/* ================================================================== */
function OverviewTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { healthSummary, incidentStats, traceStats, logStats, auditStats, operationalMetrics } = ctx;

  const cards = [
    { label: "System Health", value: healthSummary.overall === "healthy" ? "Operational" : "Degraded", sub: `${healthSummary.healthy}/${healthSummary.total} healthy`, icon: Server, tone: healthSummary.overall === "healthy" ? "success" : healthSummary.overall === "degraded" ? "warning" : "danger" },
    { label: "Active Incidents", value: incidentStats.open, sub: `${incidentStats.critical} critical`, icon: AlertTriangle, tone: incidentStats.critical > 0 ? "danger" : incidentStats.open > 0 ? "warning" : "success" },
    { label: "Traces (24h)", value: traceStats.total, sub: `${traceStats.errors} errors`, icon: Fingerprint, tone: traceStats.errors > 0 ? "warning" : "success" },
    { label: "Error Rate (24h)", value: `${logStats.errorsLast24h}`, sub: `${logStats.totalLogs} total log entries`, icon: XCircle, tone: logStats.errorsLast24h > 0 ? "warning" : "success" },
    { label: "Audit Events", value: auditStats.total, sub: `${auditStats.criticalCount} critical`, icon: Shield, tone: auditStats.criticalCount > 0 ? "danger" : "success" },
    { label: "Avg Trace Duration", value: `${traceStats.avgDurationMs}ms`, sub: `${traceStats.healthy} healthy`, icon: Clock, tone: traceStats.avgDurationMs < 500 ? "success" : "warning" },
  ];

  return (
    <div className="mt-6 space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {cards.map((c) => (
          <div key={c.label} className="card p-5">
            <div className="flex items-center justify-between">
              <span className={cn(
                "grid h-10 w-10 place-items-center rounded-full",
                c.tone === "success" ? "bg-success/15 text-success" : c.tone === "warning" ? "bg-warning/15 text-warning" : "bg-danger/15 text-danger"
              )}>
                <c.icon className="h-5 w-5" />
              </span>
              <span className={cn("h-2 w-2 rounded-full", c.tone === "success" ? "bg-success" : c.tone === "warning" ? "bg-warning" : "bg-danger")} />
            </div>
            <p className="mt-4 font-display text-xl font-semibold text-ink">{c.value}</p>
            <p className="text-sm text-muted">{c.label}</p>
            <p className="text-xs text-muted">{c.sub}</p>
          </div>
        ))}
      </div>

      {/* Key Metrics */}
      <div className="card p-5">
        <h3 className="flex items-center gap-2 font-semibold text-ink"><BarChart3 className="h-4 w-4 text-accent" /> Key Operational Metrics</h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {operationalMetrics.slice(0, 8).map((m) => (
            <div key={m.name} className="rounded-xl bg-surface2/40 p-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted">{m.name}</p>
                <span className={cn("text-xs font-medium", m.trend === "up" && m.status === "good" ? "text-success" : m.trend === "up" && m.status === "warning" ? "text-danger" : m.trend === "down" && m.status === "good" ? "text-success" : m.trend === "down" ? "text-danger" : "text-muted")}>
                  {m.changePercent > 0 ? "↑" : m.changePercent < 0 ? "↓" : "→"} {Math.abs(m.changePercent).toFixed(1)}%
                </span>
              </div>
              <p className="mt-1 text-lg font-semibold text-ink">{m.value} <span className="text-xs font-normal text-muted">{m.unit}</span></p>
              <div className="mt-2 flex items-end gap-0.5 h-8">
                {m.sparkline.map((v, i) => (
                  <div key={i} className="w-2 rounded-t bg-accent/40" style={{ height: `${(v / Math.max(...m.sparkline)) * 100}%` }} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Health Summary */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="flex items-center gap-2 font-semibold text-ink"><Server className="h-4 w-4 text-accent" /> Health Summary</h3>
          <div className="mt-4 space-y-3">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-success" />
                <span className="text-sm text-muted">{healthSummary.healthy} healthy</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-warning" />
                <span className="text-sm text-muted">{healthSummary.degraded} degraded</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-danger" />
                <span className="text-sm text-muted">{healthSummary.down} down</span>
              </div>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-surface2">
              <div className="flex h-full">
                <div className="bg-success transition-all" style={{ width: `${(healthSummary.healthy / healthSummary.total) * 100}%` }} />
                <div className="bg-warning transition-all" style={{ width: `${(healthSummary.degraded / healthSummary.total) * 100}%` }} />
                <div className="bg-danger transition-all" style={{ width: `${(healthSummary.down / healthSummary.total) * 100}%` }} />
              </div>
            </div>
            <p className="text-xs text-muted">Avg latency: {healthSummary.avgLatency}ms</p>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="flex items-center gap-2 font-semibold text-ink"><BarChart3 className="h-4 w-4 text-accent" /> Logs by Source</h3>
          <div className="mt-4 space-y-2">
            {Object.entries(logStats.bySource).slice(0, 8).map(([source, count]) => (
              <div key={source} className="flex items-center gap-3">
                <span className="w-20 text-xs font-medium text-ink capitalize">{source}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-surface2">
                  <div className="h-full rounded-full bg-accent" style={{ width: `${(count / logStats.totalLogs) * 100}%` }} />
                </div>
                <span className="text-xs text-muted">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  LOGS TAB                                                           */
/* ================================================================== */
function LogsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { logs, logStats, searchLogs } = ctx;
  const [searchText, setSearchText] = useState("");
  const [levelFilter, setLevelFilter] = useState("");

  const handleSearch = () => {
    const query: any = { limit: 100 };
    if (searchText) query.search = searchText;
    if (levelFilter) query.levels = [levelFilter];
    searchLogs(query);
  };

  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <input
            className="input-field pl-9"
            placeholder="Search logs..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
        </div>
        <select className="input-field w-auto" value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)}>
          <option value="">All levels</option>
          <option value="error">Error</option>
          <option value="warning">Warning</option>
          <option value="info">Info</option>
          <option value="debug">Debug</option>
        </select>
        <button onClick={handleSearch} className="btn-ghost btn-sm"><Filter className="h-4 w-4" /> Filter</button>
        <span className="text-xs text-muted">{logStats.totalLogs} entries</span>
      </div>

      <div className="card mt-4 overflow-hidden">
        <div className="hide-scrollbar max-h-[65vh] overflow-y-auto">
          {logs.length === 0 ? (
            <div className="flex flex-col items-center gap-2 p-8 text-muted">
              <FileText className="h-8 w-8" />
              <p className="text-sm">No log entries found</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0 border-b border-line bg-surface text-left text-xs uppercase tracking-wider text-muted">
                <tr>
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">Level</th>
                  <th className="px-4 py-3">Source</th>
                  <th className="px-4 py-3">Message</th>
                  <th className="px-4 py-3">Correlation ID</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {logs.map((l) => (
                  <tr key={l.id} className="hover:bg-surface2/40 font-mono text-xs">
                    <td className="px-4 py-2.5 text-muted whitespace-nowrap">{formatDateTime(l.ts)}</td>
                    <td className="px-4 py-2.5">
                      <span className={cn(
                        "badge capitalize",
                        l.level === "error" ? "bg-danger/15 text-danger" :
                        l.level === "warning" ? "bg-warning/15 text-warning" :
                        l.level === "debug" ? "bg-surface2 text-muted" :
                        "bg-success/15 text-success"
                      )}>{l.level}</span>
                    </td>
                    <td className="px-4 py-2.5 font-semibold text-ink">{l.source}</td>
                    <td className="px-4 py-2.5 text-muted max-w-xs truncate">{l.message}</td>
                    <td className="px-4 py-2.5 text-muted">{l.correlationId || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  TRACING TAB                                                        */
/* ================================================================== */
function TracingTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { traces, traceStats, getSpans } = ctx;
  const [selectedTrace, setSelectedTrace] = useState<string | null>(null);
  const [spans, setSpans] = useState<any[]>([]);

  const viewTrace = (id: string) => {
    setSelectedTrace(id);
    setSpans(getSpans(id));
  };

  return (
    <div className="mt-6 grid gap-6 lg:grid-cols-2">
      <div className="card overflow-hidden">
        <div className="border-b border-line px-5 py-4">
          <div className="flex items-center justify-between">
            <h3 className="flex items-center gap-2 font-semibold text-ink"><Fingerprint className="h-4 w-4 text-accent" /> Request Traces</h3>
            <span className="text-xs text-muted">{traceStats.total} total · {traceStats.avgDurationMs}ms avg</span>
          </div>
        </div>
        {traces.length === 0 ? (
          <div className="flex flex-col items-center gap-2 p-8 text-muted">
            <Fingerprint className="h-8 w-8" />
            <p className="text-sm">No traces yet</p>
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {traces.map((t) => (
              <li key={t.id}>
                <button onClick={() => viewTrace(t.id)} className={cn(
                  "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-surface2/40",
                  selectedTrace === t.id && "bg-accent-soft"
                )}>
                  <span className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-full",
                    t.status === "healthy" ? "bg-success/15 text-success" :
                    t.status === "error" ? "bg-danger/15 text-danger" :
                    "bg-warning/15 text-warning"
                  )}>
                    {t.status === "healthy" ? <CheckCircle2 className="h-4 w-4" /> :
                     t.status === "error" ? <XCircle className="h-4 w-4" /> :
                     <AlertCircle className="h-4 w-4" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-ink">{t.name}</p>
                    <p className="truncate text-xs text-muted">{t.rootOperation}</p>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-muted">
                      <span>{t.totalDurationMs || "—"}ms</span>
                      <span>·</span>
                      <span>{t.spanCount} spans</span>
                      {t.errorCount > 0 && <><span>·</span><span className="text-danger">{t.errorCount} errors</span></>}
                    </div>
                  </div>
                  <span className="text-xs text-muted">{formatDateTime(t.startTime)}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="card overflow-hidden">
        <div className="border-b border-line px-5 py-4">
          <h3 className="flex items-center gap-2 font-semibold text-ink"><GitBranch className="h-4 w-4 text-accent" /> Span Detail</h3>
        </div>
        {!selectedTrace ? (
          <div className="flex flex-col items-center gap-2 p-8 text-muted">
            <Eye className="h-8 w-8" />
            <p className="text-sm">Select a trace to view spans</p>
          </div>
        ) : spans.length === 0 ? (
          <div className="flex flex-col items-center gap-2 p-8 text-muted">
            <p className="text-sm">No span data for this trace</p>
          </div>
        ) : (
          <ul className="divide-y divide-line">
            {spans.map((span) => (
              <li key={span.id} className="flex items-start gap-3 px-4 py-3">
                <div className="relative">
                  <span className={cn(
                    "grid h-7 w-7 place-items-center rounded-full",
                    span.status === "ok" ? "bg-success/15 text-success" : "bg-danger/15 text-danger"
                  )}>
                    {span.status === "ok" ? <CheckCircle2 className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
                  </span>
                  {spans.indexOf(span) < spans.length - 1 && <div className="absolute left-3.5 top-7 h-4 w-px bg-line" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-ink">{span.operation}</p>
                  <p className="text-xs text-muted">{span.service} · {span.durationMs || "—"}ms</p>
                  {span.error && <p className="mt-0.5 text-xs text-danger">{span.error}</p>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  HEALTH TAB                                                         */
/* ================================================================== */
function HealthTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { healthChecks, healthSummary, runHealth } = ctx;

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted">{healthSummary.total} health checks · {healthSummary.healthy} healthy · {healthSummary.degraded} degraded</p>
        <button onClick={() => runHealth()} className="btn-outline btn-sm"><RefreshCw className="h-4 w-4" /> Re-check</button>
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {healthChecks.map((hc) => (
          <div key={hc.id} className="card p-4">
            <div className="flex items-center justify-between">
              <span className={cn(
                "grid h-10 w-10 place-items-center rounded-full",
                hc.status === "healthy" ? "bg-success/15 text-success" :
                hc.status === "degraded" ? "bg-warning/15 text-warning" :
                "bg-danger/15 text-danger"
              )}>
                {hc.status === "healthy" ? <CheckCircle2 className="h-5 w-5" /> :
                 hc.status === "degraded" ? <AlertTriangle className="h-5 w-5" /> :
                 <XCircle className="h-5 w-5" />}
              </span>
              <span className="text-xs font-medium text-muted">{hc.latencyMs}ms</span>
            </div>
            <p className="mt-3 text-sm font-semibold text-ink">{hc.name}</p>
            <p className="text-xs text-muted">{hc.detail}</p>
            <div className="mt-2 flex items-center gap-2">
              <span className={cn("badge capitalize", hc.status === "healthy" ? "bg-success/15 text-success" : hc.status === "degraded" ? "bg-warning/15 text-warning" : "bg-danger/15 text-danger")}>{hc.status}</span>
              {hc.consecutiveFailures > 0 && <span className="text-xs text-danger">{hc.consecutiveFailures} failures</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  INCIDENTS TAB                                                      */
/* ================================================================== */
function IncidentsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { incidents, incidentStats, updateInc } = ctx;

  const ack = (id: string) => {
    updateInc(id, { status: "investigating", action: "investigating", by: "admin", detail: "Acknowledged by admin" });
  };

  const resolve = (id: string) => {
    updateInc(id, { status: "resolved", resolvedAt: Date.now(), resolvedBy: "admin", action: "resolved", by: "admin", detail: "Resolved by admin" });
  };

  return (
    <div className="mt-6">
      <div className="flex items-center gap-4 text-sm text-muted">
        <span>{incidentStats.total} total incidents</span>
        <span className="text-warning">{incidentStats.open} open</span>
        {incidentStats.critical > 0 && <span className="text-danger">{incidentStats.critical} critical</span>}
      </div>

      {incidents.length === 0 ? (
        <div className="mt-4 flex flex-col items-center gap-2 p-8 text-muted">
          <AlertTriangle className="h-8 w-8" />
          <p className="text-sm">No incidents</p>
        </div>
      ) : (
        <div className="mt-4 space-y-3">
          {incidents.map((inc) => (
            <div key={inc.id} className={cn(
              "card p-4",
              inc.status !== "resolved" && inc.severity === "critical" && "border-danger/30",
              inc.status !== "resolved" && inc.severity === "high" && "border-warning/30"
            )}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "grid h-8 w-8 shrink-0 place-items-center rounded-full",
                      inc.severity === "critical" ? "bg-danger/15 text-danger" :
                      inc.severity === "high" ? "bg-warning/15 text-warning" :
                      inc.severity === "medium" ? "bg-accent-soft text-accent" :
                      "bg-surface2 text-muted"
                    )}>
                      <AlertTriangle className="h-4 w-4" />
                    </span>
                    <p className="font-semibold text-ink">{inc.title}</p>
                    <span className={cn(
                      "badge capitalize",
                      inc.severity === "critical" ? "bg-danger/15 text-danger" :
                      inc.severity === "high" ? "bg-warning/15 text-warning" :
                      inc.severity === "medium" ? "bg-accent-soft text-accent" :
                      "bg-surface2 text-muted"
                    )}>{inc.severity}</span>
                    <span className={cn("badge capitalize", inc.status === "resolved" ? "bg-success/15 text-success" : "bg-warning/15 text-warning")}>{inc.status}</span>
                  </div>
                  <p className="mt-1 text-xs text-muted">{inc.description}</p>
                  <p className="mt-0.5 text-xs text-muted">{inc.source} · {inc.entityType}</p>
                  <p className="mt-1 text-xs text-muted">Detected: {formatDateTime(inc.detectedAt)}</p>
                </div>
                <div className="flex gap-2">
                  {inc.status === "detected" && (
                    <button onClick={() => ack(inc.id)} className="btn-ghost btn-sm">Acknowledge</button>
                  )}
                  {(inc.status === "investigating" || inc.status === "identified" || inc.status === "monitoring") && (
                    <button onClick={() => resolve(inc.id)} className="btn-ghost btn-sm text-success">Resolve</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  AUDIT TAB                                                          */
/* ================================================================== */
function AuditTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { auditEntries, auditStats } = ctx;

  return (
    <div className="mt-6">
      <div className="grid gap-4 sm:grid-cols-4 mb-4">
        <div className="card p-3 text-center">
          <p className="text-lg font-semibold text-ink">{auditStats.total}</p>
          <p className="text-xs text-muted">Total Events</p>
        </div>
        <div className="card p-3 text-center">
          <p className="text-lg font-semibold text-danger">{auditStats.criticalCount}</p>
          <p className="text-xs text-muted">Critical</p>
        </div>
        <div className="card p-3 text-center">
          <p className="text-lg font-semibold text-ink">{Object.keys(auditStats.byAction).length}</p>
          <p className="text-xs text-muted">Unique Actions</p>
        </div>
        <div className="card p-3 text-center">
          <p className="text-lg font-semibold text-ink">{Object.keys(auditStats.byEntity).length}</p>
          <p className="text-xs text-muted">Entity Types</p>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="hide-scrollbar max-h-[70vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 border-b border-line bg-surface text-left text-xs uppercase tracking-wider text-muted">
              <tr>
                <th className="px-4 py-3">Time</th>
                <th className="px-4 py-3">Actor</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">Entity</th>
                <th className="px-4 py-3">Detail</th>
                <th className="px-4 py-3">Severity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {auditEntries.slice(0, 50).map((e) => (
                <tr key={e.id} className="hover:bg-surface2/40">
                  <td className="whitespace-nowrap px-4 py-2.5 text-xs text-muted">{formatDateTime(e.ts)}</td>
                  <td className="px-4 py-2.5 text-sm font-medium text-ink">{e.actor}</td>
                  <td className="px-4 py-2.5">
                    <span className="badge bg-surface2 capitalize text-muted">{e.action.replace(/_/g, " ")}</span>
                  </td>
                  <td className="px-4 py-2.5 text-sm text-ink">{e.entityName}</td>
                  <td className="px-4 py-2.5 text-xs text-muted max-w-xs truncate">{e.detail}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn(
                      "badge capitalize",
                      e.severity === "critical" ? "bg-danger/15 text-danger" :
                      e.severity === "warning" ? "bg-warning/15 text-warning" :
                      "bg-surface2 text-muted"
                    )}>{e.severity}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  DASHBOARDS TAB                                                     */
/* ================================================================== */
function DashboardsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { dashboards, deleteDash } = ctx;

  return (
    <div className="mt-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted">{dashboards.length} dashboards · {dashboards.filter((d) => d.starred).length} starred</p>
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {dashboards.map((d) => (
          <div key={d.id} className="card p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="h-5 w-5 text-accent" />
                <p className="font-semibold text-ink">{d.name}</p>
                {d.starred && <span className="text-yellow-500">★</span>}
              </div>
              <button onClick={() => deleteDash(d.id)} className="btn-ghost btn-sm text-danger"><Trash2 className="h-3.5 w-3.5" /></button>
            </div>
            <p className="mt-1 text-xs text-muted">{d.description}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="badge bg-surface2 capitalize text-muted">{d.category}</span>
              <span className="text-xs text-muted">{d.widgets.length} widgets</span>
              <span className="text-xs text-muted">· {d.refreshInterval / 1000}s refresh</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {d.tags.map((t) => (
                <span key={t} className="badge bg-accent-soft text-accent text-[0.6rem]">{t}</span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  ALERTS TAB                                                         */
/* ================================================================== */
function AlertsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { monitoringRules, alertEvents, acknowledgeAlertEvent, resolveAlertEvent } = ctx;
  const [subTab, setSubTab] = useState<"rules" | "events">("events");

  return (
    <div className="mt-6">
      <div className="flex gap-2 mb-4">
        <button onClick={() => setSubTab("events")} className={cn("chip", subTab === "events" && "chip-active")}>Alert Events</button>
        <button onClick={() => setSubTab("rules")} className={cn("chip", subTab === "rules" && "chip-active")}>Monitoring Rules</button>
      </div>

      {subTab === "events" && (
        <div className="space-y-3">
          {alertEvents.length === 0 ? (
            <div className="flex flex-col items-center gap-2 p-8 text-muted">
              <Bell className="h-8 w-8" />
              <p className="text-sm">No alert events</p>
            </div>
          ) : (
            alertEvents.map((ae) => (
              <div key={ae.id} className={cn(
                "card p-4",
                ae.status === "triggered" && "border-danger/30"
              )}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full",
                        ae.severity === "critical" ? "bg-danger/15 text-danger" :
                        ae.severity === "high" ? "bg-warning/15 text-warning" :
                        "bg-accent-soft text-accent"
                      )}>
                        <Bell className="h-4 w-4" />
                      </span>
                      <p className="font-semibold text-ink">{ae.ruleName}</p>
                      <span className={cn(
                        "badge capitalize",
                        ae.severity === "critical" ? "bg-danger/15 text-danger" :
                        ae.severity === "high" ? "bg-warning/15 text-warning" :
                        "bg-accent-soft text-accent"
                      )}>{ae.severity}</span>
                      <span className={cn(
                        "badge capitalize",
                        ae.status === "triggered" ? "bg-danger/15 text-danger" :
                        ae.status === "acknowledged" ? "bg-warning/15 text-warning" :
                        "bg-success/15 text-success"
                      )}>{ae.status}</span>
                    </div>
                    <p className="mt-1 text-xs text-muted">
                      {ae.ruleName} · {ae.condition} {ae.threshold}{ae.unit} · Current: {ae.value}{ae.unit}
                    </p>
                    <p className="text-xs text-muted">Triggered: {formatDateTime(ae.triggeredAt)}</p>
                  </div>
                  <div className="flex gap-2">
                    {ae.status === "triggered" && (
                      <button onClick={() => acknowledgeAlertEvent(ae.id, "admin")} className="btn-ghost btn-sm">Acknowledge</button>
                    )}
                    {(ae.status === "acknowledged" || ae.status === "triggered") && (
                      <button onClick={() => resolveAlertEvent(ae.id)} className="btn-ghost btn-sm text-success">Resolve</button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {subTab === "rules" && (
        <div className="space-y-3">
          {monitoringRules.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-full",
                    r.enabled ? "bg-success/15 text-success" : "bg-surface2 text-muted"
                  )}>
                    <Bell className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="font-medium text-ink">{r.name}</p>
                    <p className="text-xs text-muted">{r.description}</p>
                  </div>
                </div>
                <span className={cn("chip", r.enabled && "chip-active")}>{r.enabled ? "Enabled" : "Disabled"}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
                <span className="font-mono">{r.metric} {r.condition} {r.threshold}{r.unit}</span>
                <span>· {r.frequency.replace(/_/g, " ")}</span>
                <span>· Channels: {r.channels.join(", ")}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  METRICS TAB                                                        */
/* ================================================================== */
function MetricsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { operationalMetrics } = ctx;

  return (
    <div className="mt-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {operationalMetrics.map((m) => (
          <div key={m.name} className={cn(
            "card p-5",
            m.status === "warning" && "border-warning/20",
            m.status === "critical" && "border-danger/20"
          )}>
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted">{m.name}</p>
              <span className={cn(
                "text-xs font-medium",
                m.trend === "up" && m.status === "good" ? "text-success" :
                m.trend === "up" ? "text-danger" :
                m.trend === "down" && m.status === "good" ? "text-success" :
                m.trend === "down" ? "text-danger" :
                "text-muted"
              )}>
                {m.changePercent > 0 ? "↑" : m.changePercent < 0 ? "↓" : "→"} {Math.abs(m.changePercent).toFixed(1)}%
              </span>
            </div>
            <p className="mt-1 text-2xl font-semibold text-ink">
              {m.value} <span className="text-sm font-normal text-muted">{m.unit}</span>
            </p>
            <div className="mt-2 flex items-center gap-2">
              <span className={cn(
                "h-2 w-2 rounded-full",
                m.status === "good" ? "bg-success" :
                m.status === "warning" ? "bg-warning" :
                "bg-danger"
              )} />
              <span className="text-xs text-muted">{m.previousValue} {m.unit} previous</span>
            </div>
            <div className="mt-3 flex items-end gap-0.5 h-10">
              {m.sparkline.map((v, i) => (
                <div key={i} className={cn(
                  "w-2.5 rounded-t transition-all",
                  m.status === "good" ? "bg-success/40" :
                  m.status === "warning" ? "bg-warning/40" :
                  "bg-danger/40"
                )} style={{ height: `${(v / Math.max(...m.sparkline)) * 100}%` }} />
              ))}
            </div>
            <p className="mt-2 text-xs text-muted">{m.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  TOPOLOGY TAB                                                       */
/* ================================================================== */
function TopologyTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { topology } = ctx;

  const statusColor = (status: string) => {
    switch (status) {
      case "healthy": return "text-success";
      case "degraded": return "text-warning";
      case "down": return "text-danger";
      default: return "text-muted";
    }
  };

  const statusBg = (status: string) => {
    switch (status) {
      case "healthy": return "bg-success/15 border-success/30";
      case "degraded": return "bg-warning/15 border-warning/30";
      case "down": return "bg-danger/15 border-danger/30";
      default: return "bg-surface2 border-line";
    }
  };

  const typeIcon = (type: string) => {
    switch (type) {
      case "sync": return "→";
      case "async": return "↷";
      case "stream": return "⇄";
      default: return "—";
    }
  };

  return (
    <div className="mt-6">
      <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
        {topology.nodes.map((node) => (
          <div key={node.id} className={cn("card border p-4", statusBg(node.status))}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className={cn(
                  "grid h-10 w-10 place-items-center rounded-full text-lg",
                  statusColor(node.status)
                )}>
                  <Server className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold text-ink">{node.name}</p>
                  <p className="text-xs text-muted capitalize">{node.type} · v{node.version}</p>
                </div>
              </div>
              <span className={cn("badge capitalize", node.status === "healthy" ? "bg-success/15 text-success" : node.status === "degraded" ? "bg-warning/15 text-warning" : "bg-danger/15 text-danger")}>{node.status}</span>
            </div>

            {/* Dependencies */}
            {node.dependencies.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">Depends on</p>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {node.dependencies.map((dep) => {
                    const depNode = topology.nodes.find((n) => n.id === dep);
                    return (
                      <span key={dep} className={cn(
                        "badge text-[0.6rem]",
                        depNode ? (depNode.status === "healthy" ? "bg-success/15 text-success" : depNode.status === "degraded" ? "bg-warning/15 text-warning" : "bg-danger/15 text-danger") : "bg-surface2 text-muted"
                      )}>
                        {depNode?.name || dep}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Dependents */}
            {node.dependents.length > 0 && (
              <div className="mt-2">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted">Depended by</p>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {node.dependents.map((dep) => {
                    const depNode = topology.nodes.find((n) => n.id === dep);
                    return (
                      <span key={dep} className="badge bg-surface2 text-muted text-[0.6rem]">{depNode?.name || dep}</span>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Edges from this node */}
            <div className="mt-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted">Connections</p>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {topology.edges.filter((e) => e.source === node.id || e.target === node.id).slice(0, 4).map((e, i) => (
                  <span key={i} className="badge bg-surface2 text-muted font-mono text-[0.6rem]">
                    {e.source === node.id ? "→" : "←"} {topology.nodes.find((n) => n.id === (e.source === node.id ? e.target : e.source))?.name || (e.source === node.id ? e.target : e.source)}
                    <span className="ml-1 text-muted/60">{typeIcon(e.type)}</span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  REPORTS TAB                                                        */
/* ================================================================== */
function ReportsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { reports, genReport } = ctx;
  const { toast } = useToast();

  const categories: { id: OperationalReport["category"]; label: string }[] = [
    { id: "executive", label: "Executive" },
    { id: "availability", label: "Availability" },
    { id: "performance", label: "Performance" },
    { id: "error", label: "Error" },
    { id: "security", label: "Security" },
    { id: "compliance", label: "Compliance" },
    { id: "developer", label: "Developer" },
    { id: "ai", label: "AI" },
  ];

  const generate = (category: OperationalReport["category"]) => {
    genReport(category, "Last 30 days", "admin");
    toast.success(`Report generated: ${category}`);
  };

  return (
    <div className="mt-6 space-y-6">
      <div className="card p-5">
        <h3 className="flex items-center gap-2 font-semibold text-ink"><ClipboardList className="h-4 w-4 text-accent" /> Generate Report</h3>
        <div className="mt-4 flex flex-wrap gap-2">
          {categories.map((c) => (
            <button key={c.id} onClick={() => generate(c.id)} className="btn-outline btn-sm capitalize">
              <Plus className="h-3.5 w-3.5" /> {c.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {reports.length === 0 ? (
          <div className="flex flex-col items-center gap-2 p-8 text-muted">
            <ClipboardList className="h-8 w-8" />
            <p className="text-sm">No reports generated yet</p>
          </div>
        ) : (
          reports.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-ink">{r.title}</p>
                  <p className="text-xs text-muted">{r.description}</p>
                </div>
                <span className="badge bg-surface2 capitalize text-muted">{r.format}</span>
              </div>
              <div className="mt-2 flex items-center gap-3 text-xs text-muted">
                <span>Period: {r.period}</span>
                <span>· Generated: {formatDateTime(r.generatedAt)}</span>
                <span>· By: {r.createdBy}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  ERRORS TAB                                                         */
/* ================================================================== */
function ErrorsTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { errorGroups, updateErrorGroup } = ctx;

  return (
    <div className="mt-6">
      <p className="text-sm text-muted mb-4">{errorGroups.length} error groups tracked</p>
      {errorGroups.length === 0 ? (
        <div className="flex flex-col items-center gap-2 p-8 text-muted">
          <XCircle className="h-8 w-8" />
          <p className="text-sm">No errors tracked</p>
        </div>
      ) : (
        <div className="space-y-3">
          {errorGroups.map((eg) => (
            <div key={eg.id} className="card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className={cn(
                      "grid h-8 w-8 shrink-0 place-items-center rounded-full",
                      eg.status === "new" ? "bg-danger/15 text-danger" :
                      eg.status === "acknowledged" ? "bg-warning/15 text-warning" :
                      eg.status === "resolved" ? "bg-success/15 text-success" :
                      "bg-surface2 text-muted"
                    )}>
                      {eg.status === "resolved" ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                    </span>
                    <p className="font-mono text-sm font-semibold text-ink">{eg.message}</p>
                    <span className={cn(
                      "badge capitalize",
                      eg.status === "new" ? "bg-danger/15 text-danger" :
                      eg.status === "acknowledged" ? "bg-warning/15 text-warning" :
                      eg.status === "resolved" ? "bg-success/15 text-success" :
                      "bg-surface2 text-muted"
                    )}>{eg.status}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-muted">
                    <span className="font-mono">{eg.type}</span>
                    <span>· {eg.count} occurrences</span>
                    <span>· {eg.affectedUsers} affected users</span>
                    <span>· Source: {eg.source}</span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted">
                    First: {formatDateTime(eg.firstSeen)} · Last: {formatDateTime(eg.lastSeen)}
                  </p>
                </div>
                <div className="flex gap-2">
                  {eg.status === "new" && (
                    <button onClick={() => updateErrorGroup(eg.id, { status: "acknowledged" })} className="btn-ghost btn-sm">Acknowledge</button>
                  )}
                  {eg.status !== "resolved" && (
                    <button onClick={() => updateErrorGroup(eg.id, { status: "resolved" })} className="btn-ghost btn-sm text-success">Resolve</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  ACTIVITY TAB                                                       */
/* ================================================================== */
function ActivityTab({ ctx }: { ctx: ReturnType<typeof useObservability> }) {
  const { activityEvents } = ctx;

  const categoryColor = (cat: string) => {
    switch (cat) {
      case "auth": return "text-purple-500 bg-purple-500/15";
      case "crud": return "text-blue-500 bg-blue-500/15";
      case "admin": return "text-ink bg-surface2";
      case "system": return "text-cyan-500 bg-cyan-500/15";
      case "workflow": return "text-green-500 bg-green-500/15";
      case "deployment": return "text-orange-500 bg-orange-500/15";
      case "security": return "text-danger bg-danger/15";
      default: return "text-muted bg-surface2";
    }
  };

  return (
    <div className="mt-6">
      <p className="text-sm text-muted mb-4">{activityEvents.length} activity events</p>
      <div className="card overflow-hidden">
        <div className="hide-scrollbar max-h-[70vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 border-b border-line bg-surface text-left text-xs uppercase tracking-wider text-muted">
              <tr>
                <th className="px-4 py-3">Time</th>
                <th className="px-4 py-3">Actor</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">Entity</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {activityEvents.map((ae) => (
                <tr key={ae.id} className="hover:bg-surface2/40">
                  <td className="whitespace-nowrap px-4 py-2.5 text-xs text-muted">{formatDateTime(ae.ts)}</td>
                  <td className="px-4 py-2.5 text-sm font-medium text-ink">{ae.actor}</td>
                  <td className="px-4 py-2.5">
                    <span className="badge bg-surface2 capitalize text-muted">{ae.action.replace(/_/g, " ")}</span>
                  </td>
                  <td className="px-4 py-2.5 text-sm text-ink">{ae.entityName}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn("badge capitalize", categoryColor(ae.category))}>{ae.category}</span>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-muted max-w-xs truncate">{ae.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
