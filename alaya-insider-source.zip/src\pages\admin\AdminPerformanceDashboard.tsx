import { useEffect, useState } from "react";
import {
  Activity,
  Zap,
  Wifi,
  Smartphone,
  AlertTriangle,
  CheckCircle,
  HardDrive,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { Badge } from "@/components/ui";
import {
  getPerformanceReport,
  getPerformanceHistory,
  getDeviceInfo,
  isLowEndDevice,
  isSlowConnection,
  shouldReduceQuality,
  type PerformanceReport,
} from "@/lib/mobilePlatform";

function RatingIndicator({ rating }: { rating: "good" | "needs-improvement" | "poor" }) {
  const colors: Record<string, string> = {
    good: "bg-success text-white",
    "needs-improvement": "bg-warning text-white",
    poor: "bg-danger text-white",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wider", colors[rating])}>
      {rating === "good" && <CheckCircle className="h-3 w-3" />}
      {rating === "needs-improvement" && <MinusIcon className="h-3 w-3" />}
      {rating === "poor" && <AlertTriangle className="h-3 w-3" />}
      {rating}
    </span>
  );
}

function MetricSparkline({ values, color }: { values: number[]; color: string }) {
  if (values.length < 2) return <div className="h-12 text-xs text-muted">Insufficient data</div>;
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const range = max - min || 1;
  const w = 120;
  const h = 48;
  const points = values.map((v, i) => `${(i / (values.length - 1)) * w},${h - ((v - min) / range) * h}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-12 w-full max-w-[120px]">
      <polyline fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" points={points} />
    </svg>
  );
}

function ScoreGauge({ value, label }: { value: number; label: string }) {
  const pct = Math.min(100, value);
  const color = pct >= 90 ? "stroke-success" : pct >= 70 ? "stroke-warning" : "stroke-danger";
  const circumference = 2 * Math.PI * 28;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <svg width="72" height="72" viewBox="0 0 72 72" className="-rotate-90">
        <circle cx="36" cy="36" r="28" fill="none" stroke="var(--c-line)" strokeWidth="4" />
        <circle
          cx="36"
          cy="36"
          r="28"
          fill="none"
          className={color}
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
        />
      </svg>
      <span className={cn("mt-1 text-lg font-bold", color.replace("stroke-", "text-"))}>{value.toFixed(1)}</span>
      <span className="text-[0.6rem] font-semibold uppercase tracking-wider text-muted">{label}</span>
    </div>
  );
}

function MinusIcon(props: any) { return <span className="opacity-40" {...props}>—</span>; }

export default function AdminPerformanceDashboard() {
  const [perfReport, setPerfReport] = useState<PerformanceReport | null>(null);
  const [perfHistory, setPerfHistory] = useState<PerformanceReport[]>([]);

  useEffect(() => {
    setPerfReport(getPerformanceReport());
    setPerfHistory(getPerformanceHistory());

    const interval = setInterval(() => {
      setPerfReport(getPerformanceReport());
      setPerfHistory(getPerformanceHistory());
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const deviceInfo = getDeviceInfo();
  const lowEnd = isLowEndDevice();
  const slowConn = isSlowConnection();
  const reduceQuality = shouldReduceQuality();

  // Compute scores
  const computeScore = (vital: { value: number; rating: string } | null): number => {
    if (!vital) return 0;
    if (vital.rating === "good") return 100;
    if (vital.rating === "poor") return 40;
    return 70;
  };

  const lcpScore = perfReport?.lcp ? computeScore(perfReport.lcp) : 0;
  const clsScore = perfReport?.cls ? computeScore(perfReport.cls) : 0;
  const inpScore = perfReport?.inp ? computeScore(perfReport.inp) : 0;
  const fcpScore = perfReport?.fcp ? computeScore(perfReport.fcp) : 0;
  const ttfbScore = perfReport?.ttfb ? computeScore(perfReport.ttfb) : 0;
  const overallScore = Math.round((lcpScore + clsScore + inpScore + fcpScore + ttfbScore) / 5);

  // Extract metric arrays for sparklines
  const lcpHistory = perfHistory.map((p) => p.lcp?.value ?? 0).filter(Boolean);
  const clsHistory = perfHistory.map((p) => p.cls?.value ?? 0).filter(Boolean);
  const inpHistory = perfHistory.map((p) => p.inp?.value ?? 0).filter(Boolean);
  const _fcpHistory = perfHistory.map((p) => p.fcp?.value ?? 0).filter(Boolean);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-display-m text-ink">Performance Dashboard</h1>
        <p className="mt-1 text-sm text-muted">
          Core Web Vitals monitoring, device optimization, and adaptive loading insights
        </p>
      </div>

      {/* Overall score */}
      <div className="rounded-2xl border border-line bg-surface p-6 text-center">
        <div className="mb-2 flex items-center justify-center gap-2">
          <Zap className={cn("h-5 w-5", overallScore >= 80 ? "text-success" : overallScore >= 60 ? "text-warning" : "text-danger")} />
          <span className="text-sm font-semibold uppercase tracking-wider text-muted">Performance Score</span>
        </div>
        <p className={cn(
          "text-5xl font-bold",
          overallScore >= 80 ? "text-success" : overallScore >= 60 ? "text-warning" : "text-danger"
        )}>
          {overallScore}
        </p>
        <p className="mt-1 text-xs text-muted">/ 100 · {perfHistory.length} snapshots recorded</p>
      </div>

      {/* Device optimization */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-line bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <Smartphone className="h-4 w-4 text-muted" />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted">Device</span>
          </div>
          <p className="text-lg font-semibold text-ink capitalize">{deviceInfo.category}</p>
          <span className="text-xs text-muted">{deviceInfo.screenW}×{deviceInfo.screenH}</span>
        </div>
        <div className="rounded-xl border border-line bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <HardDrive className="h-4 w-4 text-muted" />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted">Device Class</span>
          </div>
          <Badge variant={lowEnd ? "warning" : "success"}>
            {lowEnd ? "Low-end" : "Standard"}
          </Badge>
        </div>
        <div className="rounded-xl border border-line bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <Wifi className="h-4 w-4 text-muted" />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted">Connection</span>
          </div>
          <Badge variant={slowConn ? "warning" : "success"}>
            {slowConn ? "Slow" : "Fast"}
          </Badge>
        </div>
        <div className="rounded-xl border border-line bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            <Activity className="h-4 w-4 text-muted" />
            <span className="text-xs font-semibold uppercase tracking-wider text-muted">Adaptive Quality</span>
          </div>
          <Badge variant={reduceQuality ? "warning" : "success"}>
            {reduceQuality ? "Reduced" : "Full"}
          </Badge>
        </div>
      </div>

      {/* Core Web Vitals */}
      <div className="rounded-2xl border border-line bg-surface p-5">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted">Core Web Vitals</h2>
        <div className="grid grid-cols-5 gap-4 mb-6">
          <ScoreGauge value={lcpScore} label="LCP" />
          <ScoreGauge value={clsScore} label="CLS" />
          <ScoreGauge value={inpScore} label="INP" />
          <ScoreGauge value={fcpScore} label="FCP" />
          <ScoreGauge value={ttfbScore} label="TTFB" />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs font-semibold uppercase tracking-wider text-muted">
                <th className="pb-2 pr-4">Metric</th>
                <th className="pb-2 pr-4">Value</th>
                <th className="pb-2 pr-4">Rating</th>
                <th className="pb-2 pr-4">Target</th>
                <th className="pb-2">Trend</th>
              </tr>
            </thead>
            <tbody>
              {[
                { label: "LCP", vital: perfReport?.lcp ?? null, target: "< 2.5s", history: lcpHistory, unit: "ms" },
                { label: "CLS", vital: perfReport?.cls ?? null, target: "< 0.1", history: clsHistory, unit: "" },
                { label: "INP", vital: perfReport?.inp ?? null, target: "< 200ms", history: inpHistory, unit: "ms" },
                { label: "FCP", vital: perfReport?.fcp ?? null, target: "< 1.8s", history: _fcpHistory, unit: "ms" },
                { label: "TTFB", vital: perfReport?.ttfb ?? null, target: "< 800ms", history: [], unit: "ms" },
              ].map((row) => (
                <tr key={row.label} className="border-b border-line/50 text-ink">
                  <td className="py-3 pr-4 font-medium">{row.label}</td>
                  <td className="py-3 pr-4">
                    {row.vital ? (
                      row.label === "CLS"
                        ? row.vital.value.toFixed(3)
                        : `${Math.round(row.vital.value)}${row.unit}`
                    ) : (
                      <span className="text-muted">—</span>
                    )}
                  </td>
                  <td className="py-3 pr-4">
                    {row.vital ? <RatingIndicator rating={row.vital.rating} /> : <span className="text-muted">Pending</span>}
                  </td>
                  <td className="py-3 pr-4 text-xs text-muted">{row.target}</td>
                  <td className="py-3">
                    {row.history.length > 1 ? (
                      <MetricSparkline values={row.history} color="var(--c-accent)" />
                    ) : (
                      <span className="text-xs text-muted">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Optimization recommendations */}
      <div className="rounded-2xl border border-line bg-surface p-5">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted">Optimization Status</h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { label: "Code Splitting", status: "active" as const },
            { label: "Lazy Loading", status: "active" as const },
            { label: "Image Optimization", status: "active" as const },
            { label: "Resource Prefetch", status: "active" as const },
            { label: "CDN Ready", status: "active" as const },
            { label: "Browser Caching", status: "active" as const },
            { label: "Reduced Motion", status: deviceInfo.reducedMotion ? "active" as const : "inactive" as const },
            { label: "Adaptive Loading", status: reduceQuality ? "active" as const : "inactive" as const },
          ].map((opt) => (
            <div key={opt.label} className={cn(
              "rounded-lg px-3 py-2.5 text-sm font-medium",
              opt.status === "active" ? "bg-success/10 text-success" : "bg-surface2 text-muted"
            )}>
              <div className="flex items-center gap-2">
                {opt.status === "active" ? <CheckCircle className="h-3.5 w-3.5" /> : <MinusIcon className="h-3.5 w-3.5" />}
                {opt.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
