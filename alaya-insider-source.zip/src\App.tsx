import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { StoreProvider } from "./context/StoreContext";
import { ThemeProvider } from "./context/ThemeContext";
import { LanguageProvider } from "./context/LanguageContext";
import { AuthProvider } from "./context/AuthContext";
import { AccountProvider } from "./context/AccountContext";
import { ToastProvider } from "./context/ToastContext";
import { SecurityProvider } from "./context/SecurityContext";
import { CommerceProvider } from "./context/CommerceContext";
import { QuickViewProvider } from "./context/QuickViewContext";
import { IdentityProvider } from "./context/IdentityContext";
import { GatewayProvider } from "./context/GatewayContext";
import { CommunicationProvider } from "./context/CommunicationContext";
import { ObservabilityProvider } from "./context/ObservabilityContext";
import { DataProvider } from "./context/DataContext";
import { IntelligenceProvider } from "./context/IntelligenceContext";
import { BusinessIntelligenceProvider } from "./context/BusinessIntelligenceContext";
import { Layout } from "./components/Layout";
import { SiteSchema } from "./components/Seo";
import { ErrorBoundary } from "./components/ErrorBoundary";
import AdminLayout, { ProtectedRoute } from "./components/admin/AdminLayout";

import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Wishlist from "./pages/Wishlist";
import Compare from "./pages/Compare";
import Account from "./pages/Account";
import Brands from "./pages/Brands";
import BrandDetail from "./pages/BrandDetail";
import Collections from "./pages/Collections";
import CollectionPage from "./pages/CollectionPage";
import RecentlyViewed from "./pages/RecentlyViewed";
import TrackOrder from "./pages/TrackOrder";
import LegalPage from "./pages/LegalPage";
import Journal from "./pages/Journal";
import ArticleDetail from "./pages/ArticleDetail";
import About from "./pages/About";
import FAQ from "./pages/FAQ";
import Contact from "./pages/Contact";
import ErrorPage from "./pages/ErrorPage";
import NotFound from "./pages/NotFound";

import AdminLogin from "./pages/admin/AdminLogin";
import AdminIdentity from "./pages/admin/AdminIdentity";
import AdminGateway from "./pages/admin/AdminGateway";
import AdminCommunications from "./pages/admin/AdminCommunications";
import AdminObservability from "./pages/admin/AdminObservability";
import AdminData from "./pages/admin/AdminData";
import AdminIntelligence from "./pages/admin/AdminIntelligence";
import AdminBusinessIntelligence from "./pages/admin/AdminBusinessIntelligence";
import Dashboard from "./pages/admin/Dashboard";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminCategories from "./pages/admin/AdminCategories";
import AdminBrands from "./pages/admin/AdminBrands";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminCoupons from "./pages/admin/AdminCoupons";
import AdminArticles from "./pages/admin/AdminArticles";
import AdminAffiliates from "./pages/admin/AdminAffiliates";
import AdminCommercePlatform from "./pages/admin/AdminCommercePlatform";
import AdminMarketingPlatform from "./pages/admin/AdminMarketingPlatform";
import AdminGlobalizationPlatform from "./pages/admin/AdminGlobalizationPlatform";
import AdminGovernancePlatform from "./pages/admin/AdminGovernancePlatform";
import AdminDeveloperPlatform from "./pages/admin/AdminDeveloperPlatform";
import AdminTestingPlatform from "./pages/admin/AdminTestingPlatform";
import AdminOperationsPlatform from "./pages/admin/AdminOperationsPlatform";
import AdminSuppliers from "./pages/admin/AdminSuppliers";
import AdminGateways from "./pages/admin/AdminGateways";
import AdminReturns from "./pages/admin/AdminReturns";
import AdminCustomers from "./pages/admin/AdminCustomers";
import AdminReviews from "./pages/admin/AdminReviews";
import AdminActivity from "./pages/admin/AdminActivity";
import AdminHomepage from "./pages/admin/AdminHomepage";
import AdminSEO from "./pages/admin/AdminSEO";
import AdminMarketing from "./pages/admin/AdminMarketing";
import AdminAnalytics from "./pages/admin/AdminAnalytics";
import AdminSystem from "./pages/admin/AdminSystem";
import AdminSecurity from "./pages/admin/AdminSecurity";
import AdminAI from "./pages/admin/AdminAI";
import AdminDesignStudio from "./pages/admin/AdminDesignStudio";
import AdminWorkflows from "./pages/admin/AdminWorkflows";
import AdminWorkflowsBpm from "./pages/admin/AdminWorkflowsBpm";
import AdminCRM from "./pages/admin/AdminCRM";
import AdminCustomerExperience from "./pages/admin/AdminCustomerExperience";
import AdminContentPlatform from "./pages/admin/AdminContentPlatform";
import AdminMedia from "./pages/admin/AdminMedia";
import AdminDeveloper from "./pages/admin/AdminDeveloper";
import AdminDevOps from "./pages/admin/AdminDevOps";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminNavigation from "./pages/admin/AdminNavigation";
import AdminTaxonomy from "./pages/admin/AdminTaxonomy";
import AdminRecommendations from "./pages/admin/AdminRecommendations";
import AdminDiscovery from "./pages/admin/AdminDiscovery";
import AdminEditorial from "./pages/admin/AdminEditorial";
import AdminAuthorProfiles from "./pages/admin/AdminAuthorProfiles";
import AdminCollectionBuilder from "./pages/admin/AdminCollectionBuilder";
import AdminAffiliateAnalytics from "./pages/admin/AdminAffiliateAnalytics";
import AdminMarketplaceRegistry from "./pages/admin/AdminMarketplaceRegistry";
import AdminCommissionEngine from "./pages/admin/AdminCommissionEngine";
import AdminPriceIntelligence from "./pages/admin/AdminPriceIntelligence";
import AdminRevenueIntelligence from "./pages/admin/AdminRevenueIntelligence";
import AdminConversionOptimization from "./pages/admin/AdminConversionOptimization";
import AdminExecutiveCenter from "./pages/admin/AdminExecutiveCenter";
import AdminOperationsCenter from "./pages/admin/AdminOperationsCenter";
import AdminNotificationsCenter from "./pages/admin/AdminNotificationsCenter";
import AdminReportingPlatform from "./pages/admin/AdminReportingPlatform";
import AdminAIAdminCenter from "./pages/admin/AdminAIAdminCenter";
import AdminDeveloperTools from "./pages/admin/AdminDeveloperTools";
import AdminOperationsQueues from "./pages/admin/AdminOperationsQueues";
import AdminAdministration from "./pages/admin/AdminAdministration";
import AdminAiWorkspaceDashboard from "./pages/admin/AdminAiWorkspaceDashboard";
import AdminAiAgentRegistry from "./pages/admin/AdminAiAgentRegistry";
import AdminAiTaskManager from "./pages/admin/AdminAiTaskManager";
import AdminAiKnowledgePlatform from "./pages/admin/AdminAiKnowledgePlatform";
import AdminAiObservability from "./pages/admin/AdminAiObservability";
import AdminAiBusinessOps from "./pages/admin/AdminAiBusinessOps";
import AdminExecutiveIntelligence from "./pages/admin/AdminExecutiveIntelligence";
import AdminBusinessHealth from "./pages/admin/AdminBusinessHealth";
import AdminForecastingCenter from "./pages/admin/AdminForecastingCenter";
import AdminDecisionIntelligence from "./pages/admin/AdminDecisionIntelligence";
import AdminDigitalTwin from "./pages/admin/AdminDigitalTwin";
import AdminExecutiveReports from "./pages/admin/AdminExecutiveReports";
import AdminExecutiveAI from "./pages/admin/AdminExecutiveAI";
import AdminMobileExperience from "./pages/admin/AdminMobileExperience";
import AdminPwaDashboard from "./pages/admin/AdminPwaDashboard";
import AdminSynchronization from "./pages/admin/AdminSynchronization";
import AdminPerformanceDashboard from "./pages/admin/AdminPerformanceDashboard";

export default function App() {
  return (
    <StoreProvider>
      <LanguageProvider>
        <ThemeProvider>
          <AuthProvider>
            <AccountProvider>
              <ToastProvider>
                <SecurityProvider>
                <IdentityProvider>
                <GatewayProvider>
                <CommunicationProvider>
                <ObservabilityProvider>
                <DataProvider>
                <IntelligenceProvider>
                <BusinessIntelligenceProvider>
                <CommerceProvider>
                  <QuickViewProvider>
                    <ErrorBoundary>
                      <HashRouter>
                      <SiteSchema />
                      <Routes>
                        {/* Storefront */}
                        <Route element={<Layout />}>
                          <Route path="/" element={<Home />} />
                          <Route path="/shop" element={<Shop />} />
                          <Route path="/product/:slug" element={<ProductDetail />} />
                          <Route path="/cart" element={<Cart />} />
                          <Route path="/checkout" element={<Checkout />} />
                          <Route path="/wishlist" element={<Wishlist />} />
                          <Route path="/compare" element={<Compare />} />
                          <Route path="/account" element={<Account />} />
                          <Route path="/brands" element={<Brands />} />
                          <Route path="/brands/:slug" element={<BrandDetail />} />
                          <Route path="/collections" element={<Collections />} />
                          <Route path="/collections/:id" element={<CollectionPage />} />
                          <Route path="/recently-viewed" element={<RecentlyViewed />} />
                          <Route path="/track-order" element={<TrackOrder />} />
                          <Route path="/journal" element={<Journal />} />
                          <Route path="/journal/:slug" element={<ArticleDetail />} />
                          <Route path="/legal/:slug" element={<LegalPage />} />
                          <Route path="/about" element={<About />} />
                          <Route path="/faq" element={<FAQ />} />
                          <Route path="/contact" element={<Contact />} />
                          <Route path="/error/:code" element={<ErrorPage />} />
                          <Route path="*" element={<NotFound />} />
                        </Route>

                        {/* Admin */}
                        <Route path="/admin/login" element={<AdminLogin />} />
                        <Route
                          path="/admin"
                          element={
                            <ProtectedRoute>
                              <AdminLayout />
                            </ProtectedRoute>
                          }
                        >
                          <Route index element={<Dashboard />} />
                          <Route path="products" element={<AdminProducts />} />
                          <Route path="categories" element={<AdminCategories />} />
                          <Route path="brands" element={<AdminBrands />} />
                          <Route path="orders" element={<AdminOrders />} />
                          <Route path="coupons" element={<AdminCoupons />} />
                          <Route path="journal" element={<AdminArticles />} />
                          <Route path="affiliates" element={<AdminAffiliates />} />
                          <Route path="commerce-platform" element={<AdminCommercePlatform />} />
                          <Route path="marketing-platform" element={<AdminMarketingPlatform />} />
                          <Route path="globalization-platform" element={<AdminGlobalizationPlatform />} />
                          <Route path="governance-platform" element={<AdminGovernancePlatform />} />
                          <Route path="developer-platform" element={<AdminDeveloperPlatform />} />
                          <Route path="testing-platform" element={<AdminTestingPlatform />} />
                          <Route path="operations-platform" element={<AdminOperationsPlatform />} />
                          <Route path="suppliers" element={<AdminSuppliers />} />
                          <Route path="gateways" element={<AdminGateways />} />
                          <Route path="returns" element={<AdminReturns />} />
                          <Route path="customers" element={<AdminCustomers />} />
                          <Route path="reviews" element={<AdminReviews />} />
                          <Route path="activity" element={<AdminActivity />} />
                          <Route path="homepage" element={<AdminHomepage />} />
                          <Route path="seo" element={<AdminSEO />} />
                          <Route path="marketing" element={<AdminMarketing />} />
                          <Route path="analytics" element={<AdminAnalytics />} />
                          <Route path="system" element={<AdminSystem />} />
                          <Route path="security" element={<AdminSecurity />} />
                          <Route path="ai" element={<AdminAI />} />
                          <Route path="design" element={<AdminDesignStudio />} />
                          <Route path="workflows" element={<AdminWorkflows />} />
                          <Route path="workflows-bpm" element={<AdminWorkflowsBpm />} />
                          <Route path="crm" element={<AdminCRM />} />
                          <Route path="customer-experience" element={<AdminCustomerExperience />} />
                          <Route path="content-platform" element={<AdminContentPlatform />} />
                          <Route path="media" element={<AdminMedia />} />
                          <Route path="developer" element={<AdminDeveloper />} />
                          <Route path="devops" element={<AdminDevOps />} />
                          <Route path="gateway" element={<AdminGateway />} />
                          <Route path="communications" element={<AdminCommunications />} />
                          <Route path="observability" element={<AdminObservability />} />
                          <Route path="data" element={<AdminData />} />
                          <Route path="intelligence" element={<AdminIntelligence />} />
                          <Route path="business-intelligence" element={<AdminBusinessIntelligence />} />
                          <Route path="identity" element={<AdminIdentity />} />
                          <Route path="navigation" element={<AdminNavigation />} />
                          <Route path="taxonomy" element={<AdminTaxonomy />} />
                          <Route path="recommendations" element={<AdminRecommendations />} />
                          <Route path="discovery" element={<AdminDiscovery />} />
                          <Route path="editorial" element={<AdminEditorial />} />
                          <Route path="authors" element={<AdminAuthorProfiles />} />
                          <Route path="collection-builder" element={<AdminCollectionBuilder />} />
                          <Route path="affiliate-analytics" element={<AdminAffiliateAnalytics />} />
                          <Route path="marketplace-registry" element={<AdminMarketplaceRegistry />} />
                          <Route path="commission-engine" element={<AdminCommissionEngine />} />
                          <Route path="price-intelligence" element={<AdminPriceIntelligence />} />
                          <Route path="revenue-intelligence" element={<AdminRevenueIntelligence />} />
                          <Route path="conversion-optimization" element={<AdminConversionOptimization />} />
                          <Route path="executive-center" element={<AdminExecutiveCenter />} />
                          <Route path="operations-center" element={<AdminOperationsCenter />} />
                          <Route path="notifications" element={<AdminNotificationsCenter />} />
                          <Route path="reporting" element={<AdminReportingPlatform />} />
                          <Route path="ai-admin" element={<AdminAIAdminCenter />} />
                          <Route path="developer-tools" element={<AdminDeveloperTools />} />
                          <Route path="operations-queues" element={<AdminOperationsQueues />} />
                          <Route path="administration" element={<AdminAdministration />} />
                          <Route path="ai-workspace" element={<AdminAiWorkspaceDashboard />} />
                          <Route path="ai-agent-registry" element={<AdminAiAgentRegistry />} />
                          <Route path="ai-task-manager" element={<AdminAiTaskManager />} />
                          <Route path="ai-knowledge" element={<AdminAiKnowledgePlatform />} />
                          <Route path="ai-observability" element={<AdminAiObservability />} />
                          <Route path="ai-business-ops" element={<AdminAiBusinessOps />} />
                          <Route path="executive-intelligence" element={<AdminExecutiveIntelligence />} />
                          <Route path="business-health" element={<AdminBusinessHealth />} />
                          <Route path="forecasting" element={<AdminForecastingCenter />} />
                          <Route path="decision-intelligence" element={<AdminDecisionIntelligence />} />
                          <Route path="digital-twin" element={<AdminDigitalTwin />} />
                          <Route path="executive-reports" element={<AdminExecutiveReports />} />
                          <Route path="executive-ai" element={<AdminExecutiveAI />} />
                          <Route path="mobile-experience" element={<AdminMobileExperience />} />
                          <Route path="pwa-dashboard" element={<AdminPwaDashboard />} />
                          <Route path="synchronization" element={<AdminSynchronization />} />
                          <Route path="performance-dashboard" element={<AdminPerformanceDashboard />} />
                          <Route path="settings" element={<AdminSettings />} />
                          <Route path="*" element={<Navigate to="/admin" replace />} />
                        </Route>
                      </Routes>
                    </HashRouter>
                  </ErrorBoundary>
                  </QuickViewProvider>
                </CommerceProvider>
                </BusinessIntelligenceProvider>
                </IntelligenceProvider>
                </DataProvider>
                </ObservabilityProvider>
                </CommunicationProvider>
                </GatewayProvider>
                </IdentityProvider>
                </SecurityProvider>
              </ToastProvider>
            </AccountProvider>
          </AuthProvider>
        </ThemeProvider>
      </LanguageProvider>
    </StoreProvider>
  );
}
