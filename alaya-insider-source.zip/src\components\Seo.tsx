import { useEffect } from "react";
import { useStore } from "../context/StoreContext";
import { removeJsonLd, setJsonLd, upsertLink, upsertMeta } from "../lib/seo";

interface SeoProps {
  title?: string;
  description?: string;
  image?: string;
  path?: string;
  type?: string;
  schema?: object | object[];
}

/** Per-page dynamic metadata + Open Graph + Twitter + JSON-LD. */
export function Seo({ title, description, image, path = "/", type = "website", schema }: SeoProps) {
  const { settings } = useStore();

  useEffect(() => {
    const fullTitle = title ? `${title} — ${settings.storeName}` : settings.seo.title;
    const desc = description || settings.seo.description;
    const img = image || settings.seo.ogImage;
    const url = `${window.location.origin}${path}`;

    document.title = fullTitle;
    upsertMeta("name", "description", desc);
    upsertMeta("name", "keywords", settings.seo.keywords);
    upsertMeta("property", "og:title", fullTitle);
    upsertMeta("property", "og:description", desc);
    upsertMeta("property", "og:type", type);
    upsertMeta("property", "og:url", url);
    upsertMeta("property", "og:image", img);
    upsertMeta("property", "og:site_name", settings.storeName);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertMeta("name", "twitter:title", fullTitle);
    upsertMeta("name", "twitter:description", desc);
    upsertMeta("name", "twitter:image", img);
    upsertLink("canonical", url);

    const schemaArr = schema ? (Array.isArray(schema) ? schema : [schema]) : [];
    schemaArr.forEach((s, i) => s && setJsonLd(`alaya-jsonld-${i}`, s));

    return () => {
      for (let i = 0; i < schemaArr.length; i++) removeJsonLd(`alaya-jsonld-${i}`);
    };
  }, [title, description, image, path, type, schema, settings]);

  return null;
}

/** Global Organization + WebSite structured data (mounted once at root). */
export function SiteSchema() {
  const { settings } = useStore();
  useEffect(() => {
    const origin = window.location.origin;
    setJsonLd("alaya-organization", {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: settings.storeName,
      url: origin,
      description: settings.description,
      email: settings.contactEmail,
      telephone: settings.contactPhone,
      logo: settings.seo.ogImage,
      image: settings.seo.ogImage,
      sameAs: Object.values(settings.social).filter(Boolean),
      address: { "@type": "PostalAddress", addressLocality: settings.address },
    });
    setJsonLd("alaya-website", {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: settings.storeName,
      url: origin,
      potentialAction: {
        "@type": "SearchAction",
        target: `${origin}/#/shop?q={search_term_string}`,
        "query-input": "required name=search_term_string",
      },
    });
    return () => {
      removeJsonLd("alaya-organization");
      removeJsonLd("alaya-website");
    };
  }, [settings]);
  return null;
}
